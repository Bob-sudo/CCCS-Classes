#include "spritesheet.h"
#include <iostream>

Spritesheet::Spritesheet(const QString &filename)
{
    spriteSheet.load(filename);

    if(!spriteSheet.load(filename))
    {
        std::cout << "FAILED TO LOAD SPRITE SHEET\n";
    }
    else
    {
        std::cout << "SPRITE SHEET LOADED\n";
    }
}

void Spritesheet::drawSprite(QPainter &painter, int row, int col,
                             double x, double y,
                             double width, double height)
{
    QRect source(row * spriteWidth, col * spriteHeight, width, height);
    QRect destination(x, y, width, height);

    painter.drawPixmap(destination, spriteSheet, source);
}
